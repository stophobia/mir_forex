const o=""+new URL("../logo_white.png",import.meta.url).href;export{o as _};
